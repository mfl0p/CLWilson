/*
 * Representation.h
 *
 *  Created on: 28.07.2011
 *      Author: Danilo Nitsche (danilo.nitsche@gmx.de)
  */

#ifndef REPRESENTATION_H_
#define REPRESENTATION_H_

#include "global.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// uncomment if release mode
//#define NDEBUG
#include <assert.h>


using namespace std;

// represents a number modulus p^2
// uses u64 where ever possible to extend maximum prime number to test from ~2^(63/2) to ~2^(64/2)
// as it uses intermediate products
class Representation {
public:
	u64 r1;       // n/p
	u64 r2;       // n (mod p)
	static u64 p; // the prime we want to check

	// Constructors
	Representation() {r1 = 0; r2 = 0;}
	Representation(i64 a) {u64 t=p+a; r1=(p+t/p-1)%p; r2=t%p; }
	Representation(u64 a1, u64 a2) { r1=a1; r2=a2;}

	// operators to easily translate formulas
	Representation operator+(Representation a) { u64 t2=r2+a.r2; u64 t1=t2/p+r1+a.r1; if (t1>=p) t1-=p; if (t2>=p) t2-=p; return Representation(t1, t2);}
//	Representation operator+(Representation a) { u64 t=r2+a.r2; return Representation((t/p+r1+a.r1)%p, t%p);}
	Representation operator-(Representation a) { u64 t=r2+p-a.r2; return Representation((r1+p-a.r1+t/p-1)%p, t%p);}
	Representation operator*(Representation a) { u64 t=r2*a.r2; return Representation((t/p+r1*a.r2+r2*a.r1)%p, t%p);}
	Representation operator/(Representation a);
	Representation operator+(i64 a) { return *this+Representation(a);}
	Representation operator-(i64 a) { return *this-Representation(a);}
	Representation operator*(i64 a) { return *this*Representation(a);}
	Representation operator/(i64 a) { return *this/Representation(a);}
	Representation operator-() { return Representation(0, 0)-*this;}
	friend Representation operator+(i64 a, Representation b) { return Representation(a)+b;}
	friend Representation operator-(i64 a, Representation b) { return Representation(a)-b;}
	friend Representation operator*(i64 a, Representation b) { return Representation(a)*b;}

	// conversion
	u64 to_u64() { return r1 * p + r2;}

    // calculates (a-b)%p with result being always positive (for u64)
	static u64 mod(i64 a) {i64 r=a%p; if (r<0) r+=p; return (u64)r;}
	static u64 diffmod(u64 a, u64 b) {if (a>b) return (a-b)%p; else return p-(b-a)%p;}
 	static Representation factorial(u64 n);
	static Representation factorialfast(u64 n);
	//static Representation factorialfast2(u64 n); // TODO, see paper for the N=0 (mod 6912) variant
	static Representation factorialAP(u64 n) { return arithmeticprogression(1, n, 1);}
	static Representation genfactorial(u64 n, u64 q);

	static Representation arithmeticprogression(u64, u64, u64);
	static i64 find_a();
	static i64 find_c();
	static i64 find_u();
	static Representation power(Representation n, u64 exp);
	static Representation power(u64 n, u64 exp) {return power(Representation(n), exp);}

	static Representation wilsonprimetest(Representation (*fac)(u64) = factorialfast);

};

#endif /* REPRESENTATION_H_ */
