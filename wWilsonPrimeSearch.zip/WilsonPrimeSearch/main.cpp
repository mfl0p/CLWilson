//============================================================================
// Name        : WilsonPrime.cpp
// Author      : Danilo Nitsche (danilo.nitsche@gmx.de)
// Version     : 0.1
// Copyright   :
// Description : Wilson prime search based on wilson.c by Francisco Sanz (Fs), frasanz@bifi.es
//============================================================================

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "global.h"
#include "Representation.h"

using namespace std;

u64 Representation::p;

int main()
{
	FILE * fi;
	FILE * fo;
	FILE * fini;
	u64 primo, compr;
	int method;
	char buff[LINESZ];
	char buff2[LINESZ];
	char buff3[LINESZ];

    printf("***** Wilson Prime Test *****\n\n");
    printf("This program takes the numbers in the file numbers and does\n");
    printf("the Wilson prime test: (p-1)!+1 mod p^2\n");
    printf("If the remainder happens to be 0 p is a Wilson prime.\n");
    printf("The remainder is put into the file output\n");
    printf("(p, remainder/p, remainder mod p).\n\n");
	/* Open input and output files */
	fi=fopen("numbers","r");
	if(fi==NULL)
	{
		printf("Error opening numbers.\n");
		exit(-1);
	}
	fo=fopen("output","a+");
	if(fo==NULL)
	{
		printf("Error opening output\n");
		exit(-1);
	}
	fini=fopen("config.ini","r");
	if(fini!=NULL)
	{
		if(fgets(buff3, LINESZ,fini))
		{
			/*We can read*/
			sscanf(buff3,"%d",&method);
		}
	} else method=5;
	printf("Available methods (set in config.ini):\n");
	printf("1: normal factorial iteration (for checking)\n");
	printf("2: faster factorial iteration\n");
	printf("3: arithmetic progression\n");
	printf("4: reduced factorial with with method 1\n");
	printf("5: reduced factorial with with method 2 (default)\n");
	printf("6: reduced factorial with with arithmetic progression\n");
	printf("The chosen method: %d\n",method);
	if (method>6) exit(-method);

	/* To the begining of fo */
	fseek(fo,0L, SEEK_SET);


	/* We read fi and fo to check if some number is done.*/
	while (fgets (buff, LINESZ, fi)) {
		if(fgets(buff2, LINESZ,fo))
		{
			/*We can read*/
			sscanf(buff,"%llu",&primo);
			sscanf(buff2,"%llu",&compr);
			if(primo!=compr)
			{
				printf("input: %llu,   output: %llu\n",primo, compr);
				printf("Both numbers must be the same!\n");
				exit(-555);
			}
		}
		else
		{
			/* We start with the calculation*/
			sscanf(buff,"%llu",&primo);
			printf("Doing the test to the prime: %llu\n", primo);
			// define global modulus
			Representation::p = primo;
			Representation m;
			switch (method) {
				case 1: m = Representation::factorial(primo-1); // original method
				case 2: m = Representation::factorialfast(primo-1); // faster method
				case 3: m = Representation::Representation::factorialAP(primo-1); // faster method
				case 4: m = Representation::wilsonprimetest(Representation::factorial);
				case 5: m = Representation::wilsonprimetest(Representation::factorialfast);
				case 6: m = Representation::wilsonprimetest(Representation::factorialAP); // asymptotically fastest method
				// the probably (asymptotic) fastest method is to use the better factorial scheme [N=0 (mod 6192)] in combination with arithmetic progression
			}
			m = m + 1;

			/* We write in the output file */
			/* the prime and the module*/
			/* If it is a wilson prime, the module must equals 0*/
			fprintf(fo,"%llu %lld %llu\n",primo, m.r1==0 ? 0: m.r1 - primo, m.r2);
		}
	}
	if(fi!=NULL) fclose(fi);
	if(fo!=NULL) fclose(fo);
	if(fini!=NULL) fclose(fini);
	return 0;
}

