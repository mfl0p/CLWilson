/*
 * global.h
 *
 *  Created on: 28.07.2011
 *      Author: Danilo Nitsche (danilo.nitsche@gmx.de)
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

typedef unsigned long long int u64;
typedef signed long long int i64;

#define LINESZ 256

#endif /* GLOBAL_H_ */
