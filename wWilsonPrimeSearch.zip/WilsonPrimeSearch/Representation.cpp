/*
 * Representation.cpp
 *
 *  Created on: 28.07.2011
 *      Author: Danilo Nitsche (danilo.nitsche@gmx.de)
 */

#include "Representation.h"

// extended GCD algorithm, finds (x,y) to solve ax+by=1 and returns x
u64 xgcd(u64 a, u64 b)
{
    if (a>b) exit(-111); // algorithm only works if a < b

    u64 c, q, oldb=b;
    i64 oldr, olds, x=1, y=0, r=0, s=1;

    while (b != 0) {
        q = a / b;
        c = a % b;
        a = b;
        b = c;
        oldr = r;
        olds = s;
        r = x - (i64)q * r;
        s = y - (i64)q * s;
        x = oldr;
        y = olds;
    }
    if (x>=0) return (u64)x;
    else return ((u64)((i64)oldb+x))%oldb;
}

Representation Representation::operator /(Representation a)
{
	assert(a.r1 < p);
	assert(a.r2 < p);
    u64 div = xgcd(a.r2, p);
    u64 ur1, ur2  = (r2*div)%p, tmp = ur2*a.r2;
    if (r2>tmp) ur1  = (diffmod(r1, ur2*a.r1+(r2-tmp)/p)*div)%p;
    else ur1 = (diffmod(diffmod(r1, ur2*a.r1), (tmp-r2)/p)*div)%p;
    return Representation(ur1, ur2);
}

/* standard iteration of the generalized factorial (mod p^2) */
Representation Representation::factorial(u64 n)
{
	Representation fac(0,1);
	u64 tmp, i;

	for (i = 2; i <= n; i++) {
		tmp    = fac.r2 * i;
		fac.r1 = (tmp / p + fac.r1 * i) % p;
		fac.r2 = tmp % p;
	}
	return fac;
}

// calculates x(x+d)(x+2d)...(x+(n-1)d)
// TODO: rewrite to use no calls of the operator +  in inner loops
Representation Representation::arithmeticprogression(u64 x, u64 n, u64 d)
{
	Representation f;
	u64 G = pow((double)n, 1/3);
	u64 K = n/G-1;
	u64 j, q;
	Representation *a = new Representation [G+1];
	for (j = 0; j <= G; j++) { a[j] = x + G*j*d; for (q = 1; q < G; q++) a[j] = a[j]*(x+(q+G*j)*d);	}
	for (q = 1; q <= G; q++) for (j = G; j >= q; j--) a[j] = a[j] - a[j-1];
	f = a[0];
	for (j = 1; j <= K; j++) {
		a[0] = a[0] + a[1];
		f = f*a[0];
		for (q = 1; q < G; q++) a[q] = a[q] + a[q+1];
	}
	for (j = G*(K+1); j < n; j++) f = f*(x+j*d);
	delete []a;
	return f;
}

/* fast iteration of the factorial (mod p^2)
 * (20 percent faster than factorial(n) ) */
Representation Representation::factorialfast(u64 n)
{
	if (n == 1) return Representation(1);
	if (n%2 != 0) return factorialfast(n-1)*n;

	Representation m = power(2, n/2)*power(genfactorial(n/2, 2), 2);
	u64 i;
	for (i = n-1; i >= n/2+1; i-=2) m = m*i;
	for (i = 2; i <= n/2; i+=2) m = m*i;
	return m;
}

// generalized factorial, in the product of the numbers up to n
// it leaves out the numbers i with i=0 (mod q)
Representation Representation::genfactorial(u64 n, u64 q)
{
	u64 i, tmp;
	Representation fac(1);

	for (i = 2; i <= n; i++) {
		if (i % q != 0)
		{
			tmp = fac.r2 * i;
			fac.r1  = (tmp / p + fac.r1 * i) % p;
			fac.r2  = tmp % p;
		}
	}

	return fac;
}

// finds a as solution of a^2+b^2=p && a=1 (mod 4)
i64 Representation::find_a()
{
	i64 a, b, b2, maxa;
	maxa = sqrt(p);
	for (a = 1; a <= maxa; a+=2) {
		b2 = p-a*a;
		b = round(sqrt(b2));
		if (b*b == b2) break;
	}
	if (a%4 == 3) return -a;
	else return a;
}

// finds c as solution of c^2+27d^2=4p && c=1 (mod 3)
i64 Representation::find_c()
{
	i64 c=0, c2, d, p4=4*p;
	i64 maxd = sqrt((double)p4/27.0);
	for (d = 1; d <= maxd; d++) {
		c2 = p4 - 27*d*d;
		c = round(sqrt(c2));
		if (c*c == c2) break;
	}
	if (c%3 == 2) return -c;
	else return c;
}

// finds u as solution of u^2+3v^2=4p && u=1 (mod 3)
i64 Representation::find_u()
{
	i64 u=0, u2, v, p4=4*p;
	i64 maxv, umod=(((p-1)/6)%2==0) ? 1 : 2;
	maxv = sqrt((double)p4/3.0);
	for (v = 1; v <= maxv; v++) {
		u2 = p4 - 3*v*v;
		u = round(sqrt(u2));
		if (u*u == u2) break;
	}
	if (u%3 == umod) return u;
	else return -u;
}

// powermod, fast calculation of n^exp (mod p^2)
Representation Representation::power(Representation n, u64 exp)
{
	Representation ret(1);
	while (exp != 0)
	{
		if (exp % 2 == 1) ret = ret * n;
		n = n * n;
		exp = exp / 2;
	}
	return ret;
}

// returns (p-1)!+1 mod p^2
Representation Representation::wilsonprimetest(Representation (*fac)(u64))
{
	if (p % 2 == 0) return (*fac)(p-1);

	if ((p > 3) && (p % 3 == 1))
	{
		i64 c = find_c();
		i64 u = find_u();
		return power((*fac)((p-1)/6), 6)*(-power(u, 3)*(power(2, p)-1)+Representation(3)*p*u)*(Representation(p)/c-c)*(power(3, p)-1)/2;
	}
	if (p % 12 == 5)  return power((*fac)((p-1)/4), 4)*(3*power(2,p)-4)*(2*power(find_a(),2)-p);
	if (p % 12 == 11) return power((*fac)((p-1)/2), 2)*(1-power(2,p));
	return (*fac)(p-1);
}

