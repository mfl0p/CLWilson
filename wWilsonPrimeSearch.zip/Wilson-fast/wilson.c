/*
 * wilson.c
 *
 *      Author: Danilo Nitsche (danilo.nitsche@gmx.de)
 */

#include <stdio.h>
#include "gmp.h"
#include <errno.h>
#include <stdlib.h>
/* compile with: icc -O3 -lgmp wilson.c -o wilson.exe
   run with "./wilson.exe <min> <max>"*/

int main(int argc, char *argv[]) {
       int exp_s, exp_f, i;
       mpz_t p, p2, q, iter, highp, q1, q2;

       if (argc != 3) {
               printf("Usage: ./wilson.exe <begin_exponent> <end_exponent>\n");
               exit(1);
       }

       exp_s = (int)strtol(argv[1], (char **)NULL, 10);
       exp_f = (int)strtol(argv[2], (char **)NULL, 10);

       if (errno == EINVAL) {
               printf("Error: argument must be an integer.\n");
               exit(1);
       }

       mpz_init(p);
       mpz_init(p2);
       mpz_init(q);
       mpz_init(q1);
       mpz_init(q2);
       mpz_init(iter);
       mpz_init(highp);

       printf("Calculating  %d!.\n",exp_s-2);
       fflush(stdout);
       mpz_fac_ui(p, exp_s-2);
       printf("Processing exponents:\n");
       fflush(stdout);
       mpz_set_ui(highp, 1);
       for (i = exp_s; i <= exp_f; i++) {
               mpz_mul_ui(highp, highp, i-1); /* use highp to avoid memory intensive multiplication with p in every cycle*/
               if (i%2 == 0 || i%3 == 0 ) continue; /* divisible by 2 or 3 */
               mpz_set_ui(iter, i); /* copy i to iter */
               if (mpz_probab_prime_p (iter, 1)==0) continue; /* composite, so continue */
               mpz_set_ui(p2, i); /* copy i to p2 */
               mpz_pow_ui(p2, p2, 2); /* p2 =p^2 */
               mpz_mul(p, p, highp); /* do the memory intensive multiplication only here once */
               mpz_set_ui(highp, 1); /* reset the temporary product */
               mpz_mod(q, p, p2); /* q = p % p2 */
               mpz_add_ui(q, q, 1); /* add 1 to the remainder */
               mpz_mod(q, q, p2); /* do a modulus just in case */
               /* now calculate the p=(q1,q2) representation with q = q1*p + q2 */
               mpz_div_ui(q1, q, i); /* q1 = q / p */
               if (mpz_cmp_ui(q1, 0)>0) mpz_sub_ui(q1, q1, i); /* make negative quotient */
               mpz_mod_ui(q2, q, i); /* calc remainder q2 = q % p */
               gmp_printf("%d %Zd %Zd\n",i, q1, q2); /* output to shell */
               if (! mpz_cmp_ui(q, 0)) { /* in case of a Wilson Prime do extra output */
                       printf("%d is a Wilson-prime \n", i); }
               fflush(stdout);
       }
}

